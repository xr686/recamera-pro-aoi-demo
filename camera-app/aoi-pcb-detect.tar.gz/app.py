"""AOI PCB Detect – reCamera Pro native app (dual-model build).

Supports two RKNN models transparently, auto-detected from first inference
output shapes (airockchip export: per scale box(64ch) + cls(NC ch) + obj(1ch)):

  * s2_pcb  (NC=1, YOLO11s PCB defect):  legacy 9-output merge path,
            score = sigmoid(cls) * sigmoid(obj), class "Issue".
  * components34 (NC=34, YOLOv8n 200ep generic electronic components,
            lukemitter7/Component-Detection v.5): cls branch is already
            sigmoided by the airockchip exporter and obj branch is redundant,
            so the 9 raw outputs go straight into kit's detect postprocess
            (it pairs branches by channel count: 64=box, 34=cls, 1=ignored).

Switch model = replace models/s2_pcb.rknn file content + restart app.
Backup of original defect model: /userdata/hackster-aoi/rknn/s2_pcb.rknn
"""
import numpy as np
from kit.app import App, run_app
from kit.runtime.postprocess import detect as detect_post

COMP34_NAMES = [
    "-", "Battery", "Button", "Buzzer", "Capacitor Jumper", "Capacitor",
    "Clock", "Connector", "Diode", "Display", "EM", "Electrolytic Capacitor",
    "Ferrite Bead", "Fuse", "Heatsink", "IC", "Inductor", "Jumper", "Led",
    "PS", "Pads", "Pins", "Potentiometer", "Resistor Jumper",
    "Resistor Network", "Resistor", "SK", "Switch", "Test Point",
    "Transformer", "Transistor", "Unknown Unlabeled", "Zener Diode", "iC",
]

# class index -> (kind, color) for OSD rendering
_GROUPS = {
    "resistor":  (["Resistor", "Resistor Network", "Resistor Jumper", "Potentiometer"], "#ff9900"),
    "capacitor": (["Capacitor", "Capacitor Jumper", "Electrolytic Capacitor"], "#00ccff"),
    "inductor":  (["Inductor", "Ferrite Bead", "Transformer"], "#aa66ff"),
    "ic":        (["IC", "iC", "Clock", "Display", "EM", "PS", "SK"], "#33cc33"),
    "diode":     (["Diode", "Zener Diode", "Led"], "#ffdd00"),
}
KIND_OF, COLOR_OF = {}, {}
for _kind, (_members, _color) in _GROUPS.items():
    for _m in _members:
        KIND_OF[_m] = _kind
        COLOR_OF[_m] = _color

def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))

class AOIPCBDetectApp(App):
    id = "aoi-pcb-detect"
    name = "AOI PCB Detect"
    owns_loop = True
    model_frame = "hw-direct"
    model_dma_input = True
    confidence = 0.35
    iou = 0.45

    def setup(self, config):
        super().setup(config)
        self._nc = None          # detected class count of active model
        self._logged_mode = False

    def _detect_mode(self, outputs):
        """NC from cls branch channel count (dim-agnostic: 4D NCHW or 3D CHW)."""
        for o in outputs:
            a = np.asarray(o)
            if a.ndim == 4:
                ch = a.shape[1]
            elif a.ndim == 3:
                ch = a.shape[0]
            else:
                continue
            if ch not in (64, 1):
                return ch
        return 1  # fallback: legacy single-class merge path

    def run(self):
        for frame in self.frames():
            prepared = self.pre(frame)
            outputs = self.models.det.infer(prepared)

            if self._nc is None:
                self._nc = self._detect_mode(outputs)

            if self._nc == len(COMP34_NAMES):
                # components34: raw 9 outputs; kit pairs box(64)/cls(34), drops obj(1)
                dets = detect_post.postprocess(
                    outputs, prepared.info,
                    conf_thres=self.confidence,
                    iou_thres=self.iou,
                    input_size=640,
                    class_names=COMP34_NAMES)
                for d in dets:
                    nm = d.get("cls_name", "")
                    d["kind"] = KIND_OF.get(nm, "component")
                    d["color"] = COLOR_OF.get(nm, "#cccccc")
            else:
                # legacy s2_pcb (NC=1): merge sigmoid(cls)*sigmoid(obj) -> 6 tensors
                merged = []
                for s in range(3):
                    box = outputs[s * 3]
                    cls = outputs[s * 3 + 1]
                    obj = outputs[s * 3 + 2]
                    merged.append(box)
                    merged.append(_sigmoid(cls) * _sigmoid(obj))
                dets = detect_post.postprocess(
                    merged, prepared.info,
                    conf_thres=self.confidence,
                    iou_thres=self.iou,
                    input_size=640,
                    class_names=["Issue"])
                for d in dets:
                    d["kind"] = "issue"
                    d["color"] = "#ff3300"

            self.emit([], frame.pts, results=dets)

if __name__ == "__main__":
    run_app(AOIPCBDetectApp())
